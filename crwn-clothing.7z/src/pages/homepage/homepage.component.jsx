import React from "react";
import './homepage.style.scss'

// Directory 
import Directory from '../../components/directory/directory.component'
// Footer


const HomePage = () => (
  <div className="homepage">
  <Directory/>
  </div>
);


export default HomePage