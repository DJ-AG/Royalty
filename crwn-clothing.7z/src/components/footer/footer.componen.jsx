import React from 'react'

import './footer.style.scss'

const Footer = () => (
    <div className='footer'>
        <div>
        <p className="paragrape">Trademark</p>
        </div> 
    </div>
)

export default Footer